Config = {}
-- Debug-inställning: true för att visa debug-information i konsolen
Config.Debug = true
Config.ExitKey = 38  -- E på tangentbordet
-- Lista över sängmodeller som spelaren kan lägga sig på
Config.Beds = {
    `v_med_bed1`,
    `v_med_bed2`,
    `v_med_emptybed`,
    `prop_bed_01`,
    `prop_bed_02`,
    `-1519439119` -- Customgjort operationsbord
}

Config.CustomBeds = {
    bed1 = {
        target = vector3(321.07, -568.4, 43.0), -- Position för ox_target interaktion
        bedcoords = vector3(321.07, -568.4, 43.5), -- Där spelaren ska placeras
        heading = 153.07  -- Vinkel spelaren ska ligga i
    },
    bed2 = {
        target = vector3(315.34, -566.4, 43.0), -- Position för ox_target interaktion
        bedcoords = vector3(315.34, -566.4, 43.0), -- Där spelaren ska placeras
        heading = 153.07  -- Vinkel spelaren ska ligga i
    },
    bed3 = {
        target = vector3(326.77, -571.08, 43.0), -- Position för ox_target interaktion
        bedcoords = vector3(326.77, -571.08, 43.0), -- Där spelaren ska placeras
        heading = 153.07  -- Vinkel spelaren ska ligga i
    },
    bed4 = {
        target = vector3(337.0, -575.23, 43.0), -- Position för ox_target interaktion
        bedcoords = vector3(337.0, -575.23, 43.0), -- Där spelaren ska placeras
        heading = 153.07  -- Vinkel spelaren ska ligga i
    },
    bed5 = {
        target = vector3(348.62, -579.46, 43.0), -- Position för ox_target interaktion
        bedcoords = vector3(348.62, -579.46, 43.0), -- Där spelaren ska placeras
        heading = 153.07  -- Vinkel spelaren ska ligga i
    },
}
-- Inställning för vilken knapp som används för att stiga upp (default: X)
Config.ExitKey = 38  -- E på tangentbordet

