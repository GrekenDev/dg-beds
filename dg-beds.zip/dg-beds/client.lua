
-- Debug-funktion för att visa meddelanden
local function DebugPrint(message)
    if Config.Debug then
        print(message)
    end
end

-- Funktion för att gå ut ur sängen
local function playGetOutOfBed(playerPed)
    -- Ta bort Text UI
    lib.hideTextUI()

    -- Ladda utgångsanimationen
    RequestAnimDict("switch@franklin@bed")

    while not HasAnimDictLoaded("switch@franklin@bed") do
        Wait(100)
    end

    -- Spela utgångsanimationen
    TaskPlayAnim(playerPed, "switch@franklin@bed", "sleep_getup_rubeyes", 8.0, 8.0, -1, 0, 0, false, false, false)

    -- Vänta på att animationen ska bli klar
    Wait(3000)

    -- Återställ kontroller och lås upp positionen
    FreezeEntityPosition(playerPed, false)
    ClearPedTasks(playerPed)

end

-- Funktion för att lägga sig på en standardbädd
local function layOnBed(bed)
    local playerPed = PlayerPedId()

    local bedCoords = GetEntityCoords(bed)
    local bedHeading = GetEntityHeading(bed)
    local bedModel = GetEntityModel(bed)

    -- Justera position beroende på modellen
    if bedModel == -1519439119 then -- Modellhash för operationsbordet
        bedCoords = vector3(bedCoords.x, bedCoords.y, bedCoords.z + 0.8) -- Anpassa höjden för operationsbordet
    else
        bedCoords = vector3(bedCoords.x, bedCoords.y, bedCoords.z + 0.5) -- Standardhöjd
    end

    SetEntityCoords(playerPed, bedCoords.x, bedCoords.y, bedCoords.z, false, false, false, true)
    SetEntityHeading(playerPed, bedHeading)
    FreezeEntityPosition(playerPed, true)


    RequestAnimDict("anim@gangops@morgue@table@")

    while not HasAnimDictLoaded("anim@gangops@morgue@table@") do
        Wait(100)
    end

    -- Spela animationen
    DebugPrint('Startar animation...')
    TaskPlayAnim(playerPed, "anim@gangops@morgue@table@", "body_search", 8.0, 8.0, -1, 1, 0, false, false, false)

    -- Visa text UI
    lib.showTextUI('[E] Kliv ur sängen', {
        style = {
            size = 20,
            position = 'left-center',
            icon = 'fas fa-bed'
        }
    })

    -- Vänta tills spelaren trycker på Config.ExitKey för att avsluta
    CreateThread(function()
        while true do
            Wait(0)

            -- Om spelaren trycker på den konfigurerade knappen
            if IsControlJustReleased(0, Config.ExitKey) then

                playGetOutOfBed(playerPed)
                break
            end
        end
    end)
end

-- Funktion för att lägga sig på en custombädd
local function layOnCustomBed(bedData)
    local playerPed = PlayerPedId()

    -- Flytta spelaren till sängen
    DebugPrint('Flyttar spelaren till custombädd på position: ' .. tostring(bedData.bedcoords))
    SetEntityCoords(playerPed, bedData.bedcoords.x, bedData.bedcoords.y, bedData.bedcoords.z, false, false, false, true)
    SetEntityHeading(playerPed, bedData.heading)
    FreezeEntityPosition(playerPed, true)


    RequestAnimDict("anim@gangops@morgue@table@")

    while not HasAnimDictLoaded("anim@gangops@morgue@table@") do
        Wait(100)
    end


    TaskPlayAnim(playerPed, "anim@gangops@morgue@table@", "body_search", 8.0, 8.0, -1, 1, 0, false, false, false)

    -- Visa text UI
    lib.showTextUI('[E] Kliv ur sängen', {
        style = {
            size = 20,
            position = 'left-center',
            icon = 'fas fa-bed'
        }
    })

    -- Vänta tills spelaren trycker på Config.ExitKey för att avsluta
    CreateThread(function()
        while true do
            Wait(0)

            -- Om spelaren trycker på den konfigurerade knappen
            if IsControlJustReleased(0, Config.ExitKey) then
                playGetOutOfBed(playerPed)
                break
            end
        end
    end)
end

-- Lägg till interaktioner för standardbäddar
CreateThread(function()
    for _, model in ipairs(Config.Beds) do
        exports.ox_target:addModel(model, {
            {
                name = 'lay_on_bed',
                icon = 'fas fa-bed',
                label = 'Lägg dig på sängen',

                    layOnBed(data.entity)
                end,
            },
        })
    end
end)

-- Lägg till interaktioner för custombäddar
CreateThread(function()
    for bedName, bedData in pairs(Config.CustomBeds) do
        exports.ox_target:addSphereZone({
            coords = bedData.target,
            radius = 1.5,
            options = {
                {
                    name = 'lay_on_bed_' .. bedName,
                    icon = 'fas fa-bed',
                    label = 'Lägg dig på sängen',
                    onSelect = function()
                        layOnCustomBed(bedData)
                    end,
                },
            },
            debug = Config.Debug
        })
    end
end)
