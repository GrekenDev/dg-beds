fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'Ditt namn'
description 'Lägg dig på sängar med ox_target och ox_lib'
version '1.0.0'

shared_script '@ox_lib/init.lua' -- Initiera ox_lib
shared_script 'config.lua' -- Din konfiguration
client_script 'client.lua' -- Din klientkod
